﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drones
{
    internal static class GlobalHelpers
    {
        public static Random alea = new Random();
    }
}
